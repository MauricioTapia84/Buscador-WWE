"""CLI wrapper that delegates to the presentation layer."""

from __future__ import annotations

import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
SRC_ROOT = REPO_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

from study_system.presentation.cli import main  # noqa: E402


if __name__ == "__main__":
    main()
